package com.firstProject.springbootCrud.controllers;

import com.firstProject.springbootCrud.entity.AuthRequest;
import com.firstProject.springbootCrud.entity.UserInfo;
import com.firstProject.springbootCrud.service.JwtService;
import com.firstProject.springbootCrud.service.UserInfoService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.Map;

@RestController
@RequestMapping("/auth")
public class UserController {

    @Autowired
    private UserInfoService service;

    @Autowired
    private JwtService jwtService;

    @Autowired
    private AuthenticationManager authenticationManager;

    @Autowired
    private PasswordEncoder encoder;

    @GetMapping("/welcome")
    public ResponseEntity<String> welcome() {
        return ResponseEntity.ok("Welcome this endpoint is not secure");
    }

    @PostMapping("/addNewUser")
    public ResponseEntity<String> addNewUser(@RequestBody UserInfo userInfo) {
        String result = service.addUser(userInfo);
        return ResponseEntity.status(HttpStatus.CREATED).body(result);  // Returning with CREATED status
    }

    @GetMapping("/user/userProfile")
    @PreAuthorize("hasAuthority('ROLE_USER')")
    public ResponseEntity<String> userProfile() {
        return ResponseEntity.ok("Welcome to User Profile for 3 minutes");
    }

    @GetMapping("/admin/adminProfile")
    @PreAuthorize("hasAuthority('ROLE_ADMIN')")
    public ResponseEntity<String> adminProfile() {
        return ResponseEntity.ok("Welcome to Admin Profile");
    }

    @PostMapping("/refreshToken")
    public ResponseEntity<Map<String, String>> refreshAccessToken(@RequestBody Map<String, String> refreshTokenRequest) {
        String refreshToken = refreshTokenRequest.get("refresh_token");

        if (refreshToken == null || refreshToken.isEmpty()) {
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(Map.of("error", "Refresh token is required"));
        }

        try {
            // Use the refresh token to generate a new access token
            String newAccessToken = jwtService.refreshAccessToken(refreshToken);

            // Return the new access token
            return ResponseEntity.ok(Map.of("access_token", newAccessToken));
        } catch (Exception e) {
            // If the refresh token is invalid or expired
            return ResponseEntity.status(HttpStatus.FORBIDDEN).body(Map.of("error", "Refresh token expired or invalid"));
        }
    }

    @PostMapping("/generateToken")
    public ResponseEntity<Map<String, String>> authenticateAndGetToken(@RequestBody AuthRequest authRequest) {
        // Log the received request body
        System.out.println("Received AuthRequest: " + authRequest);

        // Fetch user details from database
        UserDetails userDetails = service.loadUserByUsername(authRequest.getUsername());

        // Check if the password matches
        boolean passwordMatches = encoder.matches(authRequest.getPassword(), userDetails.getPassword());
        if (!passwordMatches) {
            return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body(Map.of("error", "Invalid user credentials"));
        }

        try {
            // Attempt to authenticate using AuthenticationManager
            Authentication authentication = authenticationManager.authenticate(
                    new UsernamePasswordAuthenticationToken(authRequest.getUsername(), authRequest.getPassword())
            );

            // If authentication was successful
            if (authentication != null && authentication.isAuthenticated()) {
                String accessToken = jwtService.generateToken(authRequest.getUsername());
                String refreshToken = jwtService.generateRefreshToken(authRequest.getUsername());

                // Return the tokens in the response
                Map<String, String> tokens = new HashMap<>();
                tokens.put("access_token", accessToken);
                tokens.put("refresh_token", refreshToken);

                // Log the authentication details for debugging
                System.out.println("Authentication successful with token : " + accessToken);
                System.out.println("Refresh Token: " + refreshToken);

                // Return the generated tokens as a response
                return ResponseEntity.ok(tokens); // Return the tokens in a ResponseEntity
            } else {
                return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body(Map.of("error", "Invalid user credentials"));
            }
        } catch (Exception e) {
            // Log any errors
            System.out.println("Authentication failed: " + e.getMessage() + " for request: " + authRequest);
            return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body(Map.of("error", "Authentication failed"));
        }
    }
}

package com.firstProject.springbootCrud.service;


import com.firstProject.springbootCrud.entity.UserInfo;
import com.firstProject.springbootCrud.repository.UserInfoRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.userdetails.User;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import java.util.Optional;

@Service
public class UserInfoService implements UserDetailsService {

    @Autowired
    private UserInfoRepository repository;

    @Autowired
    private PasswordEncoder encoder;


    @Override
    public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
        Optional<UserInfo> userDetail = repository.findByName(username); // Assuming 'email' is used as username

        // Log the user fetched from the database
        if (userDetail.isPresent()) {
            UserInfo userInfo = userDetail.get();
            System.out.println("Fetched User from DB: " + userInfo.getName());
            System.out.println("Password (encoded) from DB: " + userInfo.getPassword());
        }else {
            throw new UsernameNotFoundException("User not found");
        }


        // Converting UserInfo to UserDetails
        return userDetail.map(UserInfoDetails::new)
                .orElseThrow(() -> new UsernameNotFoundException("User not found: " + username));

//        UserInfo userInfo = repository.findByUsername(name)
//                .orElseThrow(() -> new UsernameNotFoundException("User not found"));
//
//        // Returning UserDetails with authorities (roles)
//        return User.builder()
//                .username(userInfo.getUsername())
//                .password(userInfo.getPassword())
//                .roles(userInfo.getRoles()) // assuming your UserInfo has a getRoles method
//                .build();

    }


    public String addUser(UserInfo userInfo) {
        // Encode password before saving the user
        userInfo.setPassword(encoder.encode(userInfo.getPassword()));
        repository.save(userInfo);
        return "User Added Successfully";

//        userInfo.setPassword(userInfo.getPassword());
    }
}
package com.firstProject.springbootCrud.controllers;

import com.firstProject.springbootCrud.entity.AuthRequest;
import com.firstProject.springbootCrud.entity.UserInfo;
import com.firstProject.springbootCrud.service.JwtService;
import com.firstProject.springbootCrud.service.UserInfoService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/auth")
public class UserController {

    @Autowired
    private UserInfoService service;

    @Autowired
    private JwtService jwtService;

    @Autowired
    private AuthenticationManager authenticationManager;
    @Autowired
    private PasswordEncoder encoder;

    @GetMapping("/welcome")
    public String welcome() {
        return "Welcome this endpoint is not secure";
    }

    @PostMapping("/addNewUser")
    public String addNewUser(@RequestBody UserInfo userInfo) {
        return service.addUser(userInfo);
    }

    @GetMapping("/user/userProfile")
    @PreAuthorize("hasAuthority('ROLE_USER')")
    public String userProfile() {
        return "Welcome to User Profile";
    }

    @GetMapping("/admin/adminProfile")
    @PreAuthorize("hasAuthority('ROLE_ADMIN')")
    public String adminProfile() {
        return "Welcome to Admin Profile";
    }

    @PostMapping("/generateToken")
    public String authenticateAndGetToken(@RequestBody AuthRequest authRequest) {
        // Log the received request body
        System.out.println("Received AuthRequest: " + authRequest);

        System.out.println("Authenticating user: " + authRequest.getUsername());
        System.out.println("With password: " + authRequest.getPassword());

        // Fetch user details from database (this will invoke the loadUserByUsername method)
        UserDetails userDetails = service.loadUserByUsername(authRequest.getUsername());

        // Log the password matching
        System.out.println("Password (encoded) from DB: " + userDetails.getPassword());

        // Check if the password matches
        boolean passwordMatches = encoder.matches(authRequest.getPassword(), userDetails.getPassword());
        System.out.println("Password matches: " + passwordMatches);


        try {
            // Attempt to authenticate using AuthenticationManager
            System.out.println("Creating AuthenticationToken with username: " + authRequest.getUsername() + ", password: " + authRequest.getPassword());
            Authentication authentication = authenticationManager.authenticate(
                    new UsernamePasswordAuthenticationToken(authRequest.getUsername(), authRequest.getPassword())
            );
            System.out.println("Authentication object: " + authentication);

            // Log the authentication details for debugging
            if (authentication != null) {
                System.out.println("Authentication successful");
                System.out.println("Username: " + authRequest.getUsername());
                System.out.println("Authorities: " + authentication.getAuthorities());
            }

            // Check if authentication was successful
            if (authentication != null && authentication.isAuthenticated()) {
                // Generate and return JWT token
                System.out.println("Authentication successful with token" + jwtService.generateToken(authRequest.getUsername()));
                return jwtService.generateToken(authRequest.getUsername());


            } else {
                throw new UsernameNotFoundException("Invalid user credentials!");
            }
        } catch (Exception e) {
            // Log any errors
            System.out.println("Authentication failed: " + e.getMessage() + " for request: " + authRequest);
            throw new UsernameNotFoundException("Invalid user request!", e);
        }
    }




//    @PostMapping("/generateToken")
//    public String authenticateAndGetToken(@RequestBody AuthRequest authRequest) {
//        Authentication authentication = authenticationManager.authenticate(
//                new UsernamePasswordAuthenticationToken(authRequest.getUsername(), authRequest.getPassword())
//        );
//        if(authentication != null){
//            System.out.println("authentication != null");
//            System.out.println(authentication.getCredentials());
//
//        }else{
//            System.out.println("authentication object null");
//        }
//
//        if (authentication != null && authentication.isAuthenticated()) {
//            return jwtService.generateToken(authRequest.getUsername());
//        } else {
//            throw new UsernameNotFoundException("Invalid user request!");
//        }
//    }
}
